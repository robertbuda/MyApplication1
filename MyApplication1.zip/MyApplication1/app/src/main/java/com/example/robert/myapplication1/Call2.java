package com.example.robert.myapplication1;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Created by Robert on 2018-02-18.
 */

public class Call2 extends AppCompatActivity {

    private TextView textViewNumber;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_call2);

        textViewNumber = (TextView) findViewById(R.id.editTextCall2);

        Intent intent = getIntent();
        String ifCheckedInCall = intent.getStringExtra(Call.KEY_DATA_CALL);

        if(ifCheckedInCall == "A"){
            makeCall();
        } else {
            makeCall();
        }


    }


    private void makeCall() {

    }
}
