package com.example.robert.myapplication1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Robert on 2018-02-18.
 */

public class Linear extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_linear);
    }



}
