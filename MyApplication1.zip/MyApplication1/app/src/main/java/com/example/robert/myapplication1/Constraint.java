package com.example.robert.myapplication1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Robert on 2018-02-16.
 */

public class Constraint extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_constraint1);
    }
}
